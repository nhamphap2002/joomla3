<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_T2support
 * @author     Tran Trong Thang <kemly.vn@gmail.com>
 * @copyright  2017
 * @license    bản quyền mã nguồn mở GNU phiên bản 2
 */
// No direct access
defined('_JEXEC') or die;

JHtml::addIncludePath(JPATH_COMPONENT . '/helpers/html');
JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');
JHtml::_('formbehavior.chosen', 'select');
JHtml::_('behavior.keepalive');

// Import CSS
$document = JFactory::getDocument();
$document->addStyleSheet(JUri::root() . 'media/com_t2support/css/form.css');
?>
<script type="text/javascript">
    js = jQuery.noConflict();
    js(document).ready(function () {

    });

    Joomla.submitbutton = function (task) {
        if (task == 'requirement.cancel') {
            Joomla.submitform(task, document.getElementById('requirement-form'));
        } else {

            if (task != 'requirement.cancel' && document.formvalidator.isValid(document.id('requirement-form'))) {
                var jform_trang_thai = jQuery('#jform_trang_thai option:selected').val();
                var jform_phan_hoi = jQuery('#jform_phan_hoi').val();
                if(jform_trang_thai=='da_tuvan'){
                    if(jQuery.trim(jform_phan_hoi)==''){
                        alert('<?php echo $this->escape(JText::_('JGLOBAL_VALIDATION_PHAN_HOI')); ?>');
                        return false;
                    }
                }
                Joomla.submitform(task, document.getElementById('requirement-form'));
            } else {
                alert('<?php echo $this->escape(JText::_('JGLOBAL_VALIDATION_FORM_FAILED')); ?>');
            }
        }
    }
</script>

<form
    action="<?php echo JRoute::_('index.php?option=com_t2support&layout=edit&id=' . (int) $this->item->id); ?>"
    method="post" enctype="multipart/form-data" name="adminForm" id="requirement-form" class="form-validate">

    <div class="form-horizontal">
        <?php echo JHtml::_('bootstrap.startTabSet', 'myTab', array('active' => 'general')); ?>

        <?php echo JHtml::_('bootstrap.addTab', 'myTab', 'general', JText::_('COM_T2SUPPORT_TITLE_REQUIREMENT', true)); ?>
        <div class="row-fluid">
            <div class="span10 form-horizontal">
                <fieldset class="adminform">

                    <input type="hidden" name="jform[id]" value="<?php echo $this->item->id; ?>" />
                    <input type="hidden" name="jform[ordering]" value="<?php echo $this->item->ordering; ?>" />
                    <input type="hidden" name="jform[state]" value="<?php echo $this->item->state; ?>" />
                    <input type="hidden" name="jform[checked_out]" value="<?php echo $this->item->checked_out; ?>" />
                    <input type="hidden" name="jform[checked_out_time]" value="<?php echo $this->item->checked_out_time; ?>" />

                    <?php echo $this->form->renderField('created_by'); ?>
                    <?php echo $this->form->renderField('modified_by'); ?>				<?php echo $this->form->renderField('hoten'); ?>
                    <?php echo $this->form->renderField('dienthoai'); ?>
                    <?php echo $this->form->renderField('website'); ?>
                    <?php echo $this->form->renderField('email'); ?>
                    <?php echo $this->form->renderField('yeu_cau'); ?>
                    <?php echo $this->form->renderField('kieu'); ?>
                    <?php echo $this->form->renderField('ngansach'); ?>
                    <?php echo $this->form->renderField('linh_vuc_kinh_doanh'); ?>
                    <?php echo $this->form->renderField('nhu_cau_thiet_ke'); ?>
                    <?php echo $this->form->renderField('trang_thai'); ?>
                    <?php echo $this->form->renderField('phan_hoi'); ?>


                    <?php if ($this->state->params->get('save_history', 1)) : ?>
                        <div class="control-group">
                            <div class="control-label"><?php echo $this->form->getLabel('version_note'); ?></div>
                            <div class="controls"><?php echo $this->form->getInput('version_note'); ?></div>
                        </div>
                    <?php endif; ?>
                </fieldset>
            </div>
        </div>
        <?php echo JHtml::_('bootstrap.endTab'); ?>



        <?php echo JHtml::_('bootstrap.endTabSet'); ?>

        <input type="hidden" name="task" value=""/>
        <?php echo JHtml::_('form.token'); ?>

    </div>
</form>
