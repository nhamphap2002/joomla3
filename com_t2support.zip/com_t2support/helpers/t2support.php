<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_T2support
 * @author     Tran Trong Thang <trantrongthang1207@gmail.com>
 * @copyright  2017 Thang Tran
 * @license    bản quyền mã nguồn mở GNU phiên bản 2
 */
// No direct access
defined('_JEXEC') or die;

/**
 * T2support helper.
 *
 * @since  1.6
 */
class T2supportHelper {

    /**
     * Configure the Linkbar.
     *
     * @param   string  $vName  string
     *
     * @return void
     */
    public static function addSubmenu($vName = '') {
        JHtmlSidebar::addEntry(
                JText::_('COM_T2SUPPORT_TITLE_REQUIREMENTS'), 'index.php?option=com_t2support&view=requirements', $vName == 'requirements'
        );
        JHtmlSidebar::addEntry(
                JText::_('COM_T2SUPPORT_TITLE_BUDGETS'), 'index.php?option=com_t2support&view=budgets', $vName == 'budgets'
        );
        JHtmlSidebar::addEntry(
                JText::_('COM_T2SUPPORT_TITLE_DESIGNNEEDS'), 'index.php?option=com_t2support&view=designneeds', $vName == 'designneeds'
        );
        JHtmlSidebar::addEntry(
                JText::_('COM_T2SUPPORT_TITLE_BUSINESSECTORS'), 'index.php?option=com_t2support&view=businesssectors', $vName == 'businesssectors'
        );
        JHtmlSidebar::addEntry(
                JText::_('COM_T2SUPPORT_TITLE_SERVICES'), 'index.php?option=com_t2support&view=services', $vName == 'services'
        );
        JHtmlSidebar::addEntry(
                JText::_('COM_T2SUPPORT_TITLE_CATEGORIES'), 'index.php?option=com_t2support&view=categories', $vName == 'categories'
        );
    }

    /**
     * Gets the files attached to an item
     *
     * @param   int     $pk     The item's id
     *
     * @param   string  $table  The table's name
     *
     * @param   string  $field  The field's name
     *
     * @return  array  The files
     */
    public static function getFiles($pk, $table, $field) {
        $db = JFactory::getDbo();
        $query = $db->getQuery(true);

        $query
                ->select($field)
                ->from($table)
                ->where('id = ' . (int) $pk);

        $db->setQuery($query);

        return explode(',', $db->loadResult());
    }

    /**
     * Gets a list of the actions that can be performed.
     *
     * @return    JObject
     *
     * @since    1.6
     */
    public static function getActions() {
        $user = JFactory::getUser();
        $result = new JObject;

        $assetName = 'com_t2support';

        $actions = array(
            'core.admin', 'core.manage', 'core.create', 'core.edit', 'core.edit.own', 'core.edit.state', 'core.delete'
        );

        foreach ($actions as $action) {
            $result->set($action, $user->authorise($action, $assetName));
        }

        return $result;
    }

    /**
     * Send email to customer when admin response
     */
    public static function sendMailToCustomer($email, $phanhoi) {
        $mailer = JFactory::getMailer();
        $recipient = array($email);

        $mailer->addRecipient($recipient);
        $params = JComponentHelper::getParams('com_t2support');
        $subject = $params->get('email_subject_user');

        $vars = array(
            'noi_dung' => $phanhoi,
        );
        $body = $params->get('email_body_user');

        foreach ($vars as $search => $replace) {
            $body = str_ireplace('{{' . $search . '}}', $replace, $body);
        }

        $mailer->isHtml(true);
        $mailer->Encoding = 'base64';
        $mailer->setSubject($subject);
        $mailer->setBody($body);
        $mailer->Send();
    }

    public static function UpdateUserSaveConfirm($item_id, $user_id) {
        if ($user_id > 0) {
            $object = new stdClass();
            $object->id = $item_id;
            $object->userid_phanhoi = $user_id;
            $result = JFactory::getDbo()->updateObject('t2_t2support_requirements', $object, 'id');
        }
    }

}
