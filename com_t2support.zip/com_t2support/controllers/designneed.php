<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_T2support
 * @author     Tran Trong Thang <trantrongthang1207@gmail.com>
 * @copyright  2017 Thang Tran
 * @license    bản quyền mã nguồn mở GNU phiên bản 2
 */

// No direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.controllerform');

/**
 * Designneed controller class.
 *
 * @since  1.6
 */
class T2supportControllerDesignneed extends JControllerForm
{
	/**
	 * Constructor
	 *
	 * @throws Exception
	 */
	public function __construct()
	{
		$this->view_list = 'designneeds';
		parent::__construct();
	}
}
