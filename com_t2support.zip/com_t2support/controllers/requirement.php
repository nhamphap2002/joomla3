<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_T2support
 * @author     Tran Trong Thang <kemly.vn@gmail.com>
 * @copyright  2017
 * @license    bản quyền mã nguồn mở GNU phiên bản 2
 */
// No direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.controllerform');

/**
 * Requirement controller class.
 *
 * @since  1.6
 */
class T2supportControllerRequirement extends JControllerForm {

    /**
     * Constructor
     *
     * @throws Exception
     */
    public function __construct() {
        $this->view_list = 'requirements';
        parent::__construct();
    }

    protected function postSaveHook($model, $validData) {
        $item = $model->getItem();
        $itemid = $item->get('id');
        $trang_thai = $item->trang_thai;
        $phan_hoi = $item->phan_hoi;
        $user = JFactory::getUser();
        $user_id = $user->id;
        //print_r($user_id);exit();
        if($trang_thai == 'da_tuvan' && $phan_hoi != ''){
            //T2supportHelper::sendMailToCustomer($item->email, $phan_hoi);
            T2supportHelper::UpdateUserSaveConfirm($itemid, $user_id);
        }
    }

}
