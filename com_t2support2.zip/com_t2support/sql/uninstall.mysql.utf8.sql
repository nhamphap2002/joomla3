DROP TABLE IF EXISTS `#__t2support_budget`;
DROP TABLE IF EXISTS `#__t2support_business_sector`;
DROP TABLE IF EXISTS `#__t2support_requirements`;
DROP TABLE IF EXISTS `#__t2support_design_needs`;
DROP TABLE IF EXISTS `#__t2support_services`;
DROP TABLE IF EXISTS `#__t2support_categories`;
DROP TABLE IF EXISTS `#__t2support_orders`;

