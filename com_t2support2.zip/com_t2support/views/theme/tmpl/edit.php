<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_T2support
 * @author     Tran Trong Thang <trantrongthang1207@gmail.com>
 * @copyright  2017 Thang Tran
 * @license    báº£n quyá»n mÃ£ nguá»“n má»Ÿ GNU phiÃªn báº£n 2
 */
// No direct access
defined('_JEXEC') or die;

JHtml::addIncludePath(JPATH_COMPONENT . '/helpers/html');
JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');
JHtml::_('formbehavior.chosen', 'select');
JHtml::_('behavior.keepalive');

// Import CSS
$document = JFactory::getDocument();
$document->addStyleSheet(JUri::root() . 'media/com_t2support/css/form.css');
?>
<script type="text/javascript">
    js = jQuery.noConflict();
    js(document).ready(function () {

        js('input:hidden.category_ids').each(function () {
            var name = js(this).attr('name');
            if (name.indexOf('category_idshidden')) {
                js('#jform_category_ids option[value="' + js(this).val() + '"]').attr('selected', true);
            }
        });
        js("#jform_category_ids").trigger("liszt:updated");
    });

    Joomla.submitbutton = function (task) {
        if (task == 'theme.cancel') {
            Joomla.submitform(task, document.getElementById('theme-form'));
        } else {

            if (task != 'theme.cancel' && document.formvalidator.isValid(document.id('theme-form'))) {

                if (js('#jform_category_ids option:selected').length == 0) {
                    js("#jform_category_ids option[value=0]").attr('selected', 'selected');
                }
                Joomla.submitform(task, document.getElementById('theme-form'));
            } else {
                alert('<?php echo $this->escape(JText::_('JGLOBAL_VALIDATION_FORM_FAILED')); ?>');
            }
        }
    }
</script>

<form
    action="<?php echo JRoute::_('index.php?option=com_t2support&layout=edit&id=' . (int) $this->item->id); ?>"
    method="post" enctype="multipart/form-data" name="adminForm" id="theme-form" class="form-validate">

    <div class="form-horizontal">
        <?php echo JHtml::_('bootstrap.startTabSet', 'myTab', array('active' => 'general')); ?>

        <?php echo JHtml::_('bootstrap.addTab', 'myTab', 'general', JText::_('COM_T2SUPPORT_TITLE_THEME', true)); ?>
        <div class="row-fluid">
            <div class="span10 form-horizontal">
                <fieldset class="adminform">

                    <input type="hidden" name="jform[id]" value="<?php echo $this->item->id; ?>" />
                    <input type="hidden" name="jform[ordering]" value="<?php echo $this->item->ordering; ?>" />
                    <input type="hidden" name="jform[state]" value="<?php echo $this->item->state; ?>" />
                    <input type="hidden" name="jform[checked_out]" value="<?php echo $this->item->checked_out; ?>" />
                    <input type="hidden" name="jform[checked_out_time]" value="<?php echo $this->item->checked_out_time; ?>" />

                    <?php echo $this->form->renderField('created_by'); ?>
                    <?php echo $this->form->renderField('modified_by'); ?>				<?php echo $this->form->renderField('name'); ?>
                    <?php echo $this->form->renderField('alias'); ?>
                    <?php echo $this->form->renderField('description'); ?>
                    <?php echo $this->form->renderField('images'); ?>

                    <?php if (!empty($this->item->images)) : ?>
                        <div class="control-group">
                            <div class="control-label">&nbsp;</div>
                            <div class="controls">
                                <?php
                                $ii = 0;
                                $imageThemes = array();
                                foreach ((array) $this->item->images as $fileSingle) :
                                    ?>
                                    <?php
                                    if (!is_array($fileSingle)) :
                                        $imageThemes[] = $fileSingle;
                                        ?>
                                        <a href="<?php echo JRoute::_(JUri::root() . 'images/themes' . DIRECTORY_SEPARATOR . $fileSingle, false); ?>">
                                            <img src="<?php echo JRoute::_(JUri::root() . 'images/themes' . DIRECTORY_SEPARATOR . $fileSingle, false); ?>" width="100px"/>
                                        </a>
                                        <?php
                                        if ($ii == 0)
                                            echo ' | ';
                                    endif;
                                    $ii++;
                                    ?>
                                <?php endforeach;
                                ?>
                            </div>
                        </div>
                    <?php endif; ?>
                    <input type="hidden" name="jform[images_hidden]" id="jform_images_hidden" value="<?php echo implode(',', $imageThemes); ?>" />
                    <?php echo $this->form->renderField('price'); ?>
                    <?php echo $this->form->renderField('special_price'); ?>
                    <?php echo $this->form->renderField('highlights'); ?>
                    <?php echo $this->form->renderField('bestseller'); ?>
                    <?php echo $this->form->renderField('category_ids'); ?>

                    <?php
                    foreach ((array) $this->item->category_ids as $value):
                        if (!is_array($value)):
                            echo '<input type="hidden" class="category_ids" name="jform[category_idshidden][' . $value . ']" value="' . $value . '" />';
                        endif;
                    endforeach;
                    ?>				<input type="hidden" name="jform[website]" value="<?php echo $this->item->website; ?>" />
                    <input type="hidden" name="jform[created_date]" value="<?php echo $this->item->created_date; ?>" />
                    <input type="hidden" name="jform[publish_up]" value="<?php echo $this->item->publish_up; ?>" />


                    <?php if ($this->state->params->get('save_history', 1)) : ?>
                        <div class="control-group">
                            <div class="control-label"><?php echo $this->form->getLabel('version_note'); ?></div>
                            <div class="controls"><?php echo $this->form->getInput('version_note'); ?></div>
                        </div>
                    <?php endif; ?>
                </fieldset>
            </div>
        </div>
        <?php echo JHtml::_('bootstrap.endTab'); ?>



        <?php echo JHtml::_('bootstrap.endTabSet'); ?>

        <input type="hidden" name="task" value=""/>
        <?php echo JHtml::_('form.token'); ?>

    </div>
</form>
