
            <title>Commweb hosted checkout</title>
            <style>
                #loading{
                    position: fixed;
                    left: 0px;
                    top: 0px;
                    width: 100%;
                    height: 100%;
                    z-index: 9999;
                    background: url('http://jl3.trongthang.wdev.fgct.net//plugins/vmpayment/commweb/images/loading.gif') 50% 50% no-repeat;
                }
            </style>
            <script src="https://paymentgateway.commbank.com.au/checkout/version/41/checkout.js" 
                    data-return="completeCallback"
                    data-complete="completeCallback"
                    data-cancel="cancelCallback">
            </script>

            <script type="text/javascript">
                completeCallback = "http://jl3.trongthang.wdev.fgct.net//index.php?option=com_virtuemart&view=pluginresponse&task=pluginnotification&pm=2&on=Z2P8079&Itemid=0&lang=";
                cancelCallback = "http://jl3.trongthang.wdev.fgct.net/index.php?option=com_virtuemart&view=vmplg&task=pluginUserPaymentCancel&on=Z2P8079&pm=2&Itemid=0&lang=";
                Checkout.configure({
                    merchant: "TESTAMBBUICOM201",
                    session: {
                        id: "SESSION0002536187811I1192542J30"
                    },
                    order: {
                        amount: "128.5",
                        currency: "AUD",
                        description: "Commweb Order",
                        id: "Z2P8079_0646567001493220734"
                    },
                    billing: {
                        address: {
                            street: "Whiskey St",
                            city: "Sydney",
                            postcodeZip: "4556",
                            stateProvince: "NS",
                            country: "AUS"
                        }
                    },
                    interaction: {
                        merchant: {
                            name: "Commweb hosted checkout"
                        }
                    }
                });
                var loadcheckout = setInterval(function () {
                    if (typeof Checkout != 'defined') {
            Checkout.showPaymentPage();                        clearInterval(loadcheckout);
                    }
                }, 100)

            </script>
            <div id="loading"></div>
            