Commưeb
===========================

Commweb payment gateway virtuemart 3 joomla 3

Install
============================
1. Login account admin on area administrator
2. Goto Extensions -> Manage -> Install
3. Upload zip fie plugin
3. Enable and configure commweb Goto Virtuemart -> Payment methods -> choose new a payment method
  - Choose payment methoad: VM Payment - Commweb
  - Please save it after enter information account payment in Configuration tab and save it
