jQuery(document).ready(function ($) {
    var $action = window.location.href;
    if ($action.indexOf('#__hc-action-complete') != -1) {
        location.href = 'index.php?option=com_virtuemart&view=pluginresponse&task=pluginnotification&commweb=1'
        /*$.ajax({
            url: 'plugins/vmpayment/commweb/loadjs.php',
            success: function (data, textStatus, jqXHR) {
                $('body').append(data)
            }
        })*/
    }
})
